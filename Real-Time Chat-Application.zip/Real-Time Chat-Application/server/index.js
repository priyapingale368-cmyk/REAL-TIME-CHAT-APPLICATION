import { WebSocketServer } from "ws";

const wss = new WebSocketServer({ port: 8080 });

// Store message history
const messages = [];

wss.on("connection", (ws) => {
  console.log("Client connected");

  // Send chat history to new client
  ws.send(JSON.stringify({ type: "history", data: messages }));

  ws.on("message", (message) => {
    const parsed = JSON.parse(message);

    if (parsed.type === "message") {
      const chatMessage = {
        text: parsed.text,
        timestamp: new Date().toISOString(),
      };

      messages.push(chatMessage);

      // Broadcast to all clients
      wss.clients.forEach((client) => {
        if (client.readyState === ws.OPEN) {
          client.send(
            JSON.stringify({ type: "message", data: chatMessage })
          );
        }
      });
    }
  });

  ws.on("close", () => {
    console.log("Client disconnected");
  });
});

console.log("WebSocket server running on ws://localhost:8080");

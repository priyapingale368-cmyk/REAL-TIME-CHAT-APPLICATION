import { useEffect, useRef, useState } from "react";

const socket = new WebSocket("ws://localhost:8080");

function App() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const bottomRef = useRef(null);

  useEffect(() => {
    socket.onmessage = (event) => {
      const payload = JSON.parse(event.data);

      if (payload.type === "history") {
        setMessages(payload.data);
      }

      if (payload.type === "message") {
        setMessages((prev) => [...prev, payload.data]);
      }
    };
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = () => {
    if (!input.trim()) return;

    socket.send(
      JSON.stringify({
        type: "message",
        text: input,
      })
    );

    setInput("");
  };

  return (
    <div className="chat-container">
      <header className="chat-header">💬 WebSocket Chat</header>

      <div className="chat-messages">
        {messages.map((msg, idx) => (
          <div className="message" key={idx}>
            <span>{msg.text}</span>
            <small>{new Date(msg.timestamp).toLocaleTimeString()}</small>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      <div className="chat-input">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && sendMessage()}
          placeholder="Type a message..."
        />
        <button onClick={sendMessage}>Send</button>
      </div>
    </div>
  );
}

export default App;
